# FlyAI > 2022-08-18 10:42am
https://universe.roboflow.com/object-detection/flyai-vp1ai

Provided by Roboflow
License: Public Domain

